<?php

namespace Keleo\CVGenerator;

class Reference extends BaseVcObject
{
    /**
     * @var string
     */
    private $title = '';
    /**
     * @var string
     */
    private $url = '';

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $url
     */
    public function setUrl($url)
    {
        $this->url = $url;
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

}