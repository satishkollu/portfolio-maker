<?php

return array(
    'About'             => 'About me',
    'Education'         => 'Education',
    'Expertise'         => 'Expertise',
    'Experience'        => 'Experience',
    'Knowledge'         => 'Knowledge',
    'Projects'          => 'Projects',
    'Works'             => 'Works',
    'Years'             => 'Years',
    'Month'             => 'Month',
    'Go to Top'         => 'Go to Top',
    'Experience Level'  => 'Experience Level',
    'Business'          => 'Business',
    'Website'           => 'Website',
    'Technologies'      => 'Technologies',
    'Address'           => 'Address',
    'Email'             => 'Email',
    'Phone'             => 'Phone',
    'Home'              => 'Home',
    'Email me'          => 'Email me',
    'Contact details'   => 'Contact details',
    'Reference'         => 'Reference'
);