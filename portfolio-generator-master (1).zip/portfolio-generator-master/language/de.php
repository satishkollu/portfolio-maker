<?php

return array(
    'About'             => 'Über mich',
    'Education'         => 'Ausbildung',
    'Expertise'         => 'Expertise',
    'Experience'        => 'Erfahrung',
    'Knowledge'         => 'Kenntnisse',
    'Projects'          => 'Projekte',
    'Works'             => 'Referenzen',
    'Years'             => 'Jahre',
    'Month'             => 'Monate',
    'Go to Top'         => 'Nach oben',
    'Experience Level'  => 'Erfahrungslevel',
    'Business'          => 'Unternehmen',
    'Website'           => 'Webseite',
    'Technologies'      => 'Technologien',
    'Address'           => 'Adresse',
    'Email'             => 'Email',
    'Phone'             => 'Telefon',
    'Home'              => 'Home',
    'Email me'          => 'Email senden',
    'Contact details'   => 'Kontaktdaten',
    'Reference'         => 'Referenz'
);